# CFO Helper Agent

A simple finance helper to simulate scenarios (pricing, marketing spend, hiring), visualize forecasts, export reports, count usage, and (mock) bill per action. Includes a live data stream simulating Pathway updates and optional AI recommendations.

## Features
- Sliders for price change, marketing spend, hires, conversion lift, forecast months
- Text and chart forecast (monthly profit, runway)
- Export summary to PDF
- Usage counter and mock billing (per scenario/report)
- Live Server-Sent Events endpoint to mimic Pathway data changes
- Agent recommendations with strategy modes (balanced, cost, growth, pricing, cash, runway)

## Setup (Windows PowerShell)

### 1) Backend
```powershell
cd d:\CODES\CFO_Helper\backend
npm install
```

#### Configure environment (.env) [optional]
If needed, create `d:\CODES\CFO_Helper\backend\.env` from the example and override `PORT`.
```powershell
Copy-Item .env.example .env
notepad .env
```

#### Run backend
```powershell
npm run dev
```
You should see: `CFO Helper backend running on :5050`

### 2) Frontend
Open `d:\CODES\CFO_Helper\frontend\index.html` in your browser. If browser blocks file:// → http, serve it:
```powershell
npx http-server d:\CODES\CFO_Helper\frontend -p 5500
start http://localhost:5500
```

### 3) Verify
```powershell
Invoke-RestMethod -Uri http://localhost:5050/api/usage -Method GET | ConvertTo-Json
$body = @{ priceChangePct = 5; marketingExtra = 10000; hires = 1; conversionLiftPct = 2; mode = 'pricing' } | ConvertTo-Json
Invoke-RestMethod -Uri http://localhost:5050/api/recommend -Method POST -ContentType 'application/json' -Body $body | ConvertTo-Json -Depth 5
```

## Agent Strategy Modes

- balanced: Default blended guidance (cost + growth hygiene)
- cost: Aggressive cost savings to reduce burn
- growth: Scale proven channels with guardrails
- pricing: Optimize price/packaging for margin and ARPU
- cash: Improve working capital and cash conversion
- runway: Extend runway and converge to breakeven

Usage:
- UI: Pick a mode from the “Agent Strategy” dropdown before clicking “Get Advice”.
- API: Include `mode` in the POST body to `/api/recommend`.
	- Example:
		```powershell
		$Body = '{"priceChangePct":0,"marketingExtra":0,"hires":0,"conversionLiftPct":0,"mode":"runway"}'
		Invoke-RestMethod -Uri http://localhost:5050/api/recommend -Method POST -ContentType 'application/json' -Body $Body | ConvertTo-Json -Depth 5
		```

## Notes
- Flexprice billing is mocked via in-memory counters in `server.js`.
- Pathway is simulated as SSE; swapping to real Pathway would require their client and source integration.
 
