import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';

const app = express();
app.use(cors());
app.use(express.json());

// These are not available in ES module scope, so we recreate them
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 3000;

// --- Mock financial state (replace later with Pathway live data) ---
let mockData = {
  cash: 100000,            // starting cash in INR
  monthlyRevenue: 20000,   // base monthly revenue
  monthlyExpenses: 25000   // base monthly expenses
};

let usage = { scenarios: 0, reports: 0, billed: 0 };

const MOCK_COST_PER_HIRE = 50000; // monthly cost per hire in INR
const MOCK_BASE_GROWTH_RATE = 0.08; // 8% annual growth
const MOCK_SEASONALITY_FACTOR = 0.05; // 5% seasonality
const MOCK_NOISE_FACTOR = 0.02; // 2% noise

// Serve frontend static files
app.use(express.static(path.join(__dirname, '../frontend')));

// Get usage counters
app.get('/api/usage', (req, res) => res.json(usage));

// Simulation endpoint
app.post('/api/simulate', (req, res) => {
  const {
    priceChangePct,
    marketingExtra,
    hires,
    conversionLiftPct,
    months,
    dynamic,
    baseGrowthPct,
    seasonalityPct,
    noisePct
  } = req.body;

  const priceFactor = 1 + (priceChangePct / 100);
  const conversionFactor = 1 + (conversionLiftPct / 100);

  const monthlyExpensesAdjusted = mockData.monthlyExpenses + (hires * MOCK_COST_PER_HIRE) + marketingExtra;
  const monthlyRevenueAdjusted = mockData.monthlyRevenue * priceFactor * conversionFactor;
  const monthlyProfit = monthlyRevenueAdjusted - monthlyExpensesAdjusted;

  let runwayMonths = null;
  if (monthlyProfit < 0) {
    runwayMonths = Number((mockData.cash / -monthlyProfit).toFixed(2));
  } else {
    runwayMonths = Infinity;
  }

  // Build a cash and profit trajectory
  const forecast = [];
  let currentCash = mockData.cash;
  let currentRevenue = monthlyRevenueAdjusted;
  
  for (let i = 0; i < months; i++) {
    let revenueForMonth = currentRevenue;
    let expensesForMonth = monthlyExpensesAdjusted;
    
    // Apply dynamic factors if enabled
    if (dynamic) {
        const growth = 1 + ((baseGrowthPct || MOCK_BASE_GROWTH_RATE * 100) / 100 / 12);
        const seasonality = (seasonalityPct || MOCK_SEASONALITY_FACTOR * 100) / 100;
        const noise = (noisePct || MOCK_NOISE_FACTOR * 100) / 100;
        
        // Simple seasonality: sine wave for a 12-month cycle
        const seasonalityEffect = Math.sin((i / 12) * 2 * Math.PI) * seasonality * currentRevenue;
        // Simple noise: random fluctuation
        const noiseEffect = (Math.random() - 0.5) * 2 * noise * currentRevenue;

        revenueForMonth = currentRevenue * growth + seasonalityEffect + noiseEffect;
        expensesForMonth = monthlyExpensesAdjusted * (1 + (Math.random() - 0.5) * 0.05); // a little expense noise too
    }

    const profitForMonth = revenueForMonth - expensesForMonth;
    currentCash += profitForMonth;
    
    forecast.push({
      month: i + 1,
      revenue: Math.round(revenueForMonth),
      expenses: Math.round(expensesForMonth),
      profit: Math.round(profitForMonth),
      cash: Math.round(currentCash),
    });

    currentRevenue = revenueForMonth; // for compounding growth
  }

  usage.scenarios += 1;

  return res.json({
    results: {
      adjustedRevenue: monthlyRevenueAdjusted,
      adjustedExpenses: monthlyExpensesAdjusted,
      monthlyProfit,
      runwayMonths,
      forecast
    },
    usage
  });
});

// Report endpoint (we increment report usage count and bill amount here)
app.post('/api/report', (req, res) => {
  usage.reports += 1;
  usage.billed += 500; // Mock billing: ₹500 per report
  return res.json({ success: true, usage });
});

// Mock agent recommendations
app.post('/api/recommend', (req, res) => {
  const { mode } = req.body;
  
  let advice = [];
  switch(mode) {
    case 'cost':
      advice = [
        { action: 'Review and cut non-essential expenses', rationale: 'This will have an immediate impact on your monthly burn rate.' },
        { action: 'Consider reducing new hires', rationale: 'This is a significant fixed cost and can be delayed in a cash-focused strategy.' },
        { action: 'Optimize marketing spend', rationale: 'Ensure every rupee spent is generating a positive return.' }
      ];
      break;
    case 'growth':
      advice = [
        { action: 'Increase marketing budget aggressively', rationale: 'Focus on high-ROI channels to drive top-line revenue growth.' },
        { action: 'Invest in new hires for key roles', rationale: 'Expand your team in sales, marketing, and product development.' },
        { action: 'Offer a promotional pricing change', rationale: 'A small price decrease can significantly boost customer acquisition and market share.' }
      ];
      break;
    case 'pricing':
      advice = [
        { action: 'Test a small price increase', rationale: 'A price increase can dramatically improve profit margins without losing many customers.' },
        { action: 'Bundle products or services', rationale: 'Offering premium bundles can increase the average order value (AOV).' },
        { action: 'Implement a tiered pricing model', rationale: 'Capture different customer segments and provide options for higher value customers.' }
      ];
      break;
    default:
      advice = [
        { action: 'Maintain a balanced approach', rationale: 'Continue with moderate marketing and selective hiring to ensure sustainable growth.' },
        { action: 'Continuously monitor key metrics', rationale: 'Keep a close eye on your revenue, expenses, and runway to pivot when needed.' }
      ];
      break;
  }
  return res.json({ advice, mode });
});

// ------------------- Server-Sent Events for live updates (Pathway mock) -------------------
const sseClients = [];
app.get('/api/stream/pathway', (req, res) => {
  res.set({
    'Cache-Control': 'no-cache',
    'Content-Type': 'text/event-stream',
    Connection: 'keep-alive'
  });
  res.flushHeaders();
  sseClients.push(res);
  req.on('close', () => {
    const idx = sseClients.indexOf(res);
    if (idx >= 0) sseClients.splice(idx, 1);
  });
});

function broadcastEvent(data) {
  sseClients.forEach((res) => {
    res.write(`data: ${JSON.stringify(data)}\n\n`);
  });
}

// Endpoint to update mock financials (simulate Pathway pushing new data)
app.post('/api/update-mock', (req, res) => {
  const updates = req.body || {};
  mockData = { ...mockData, ...updates };
  broadcastEvent({ timestamp: new Date(), type: 'mock-update', mockData });
  return res.json({ success: true, mockData });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});
