const apiBase = 'http://localhost:3000/api';

const priceEl = document.getElementById('priceChange');
const priceNum = document.getElementById('priceChangeNum');
const mktEl = document.getElementById('marketingExtra');
const mktNum = document.getElementById('marketingExtraNum');
const hireEl = document.getElementById('hires');
const hireNum = document.getElementById('hiresNum');
const convEl = document.getElementById('conversionLiftPct');
const convNum = document.getElementById('conversionLiftPctNum');
const monthsEl = document.getElementById('months');
const monthsNum = document.getElementById('monthsNum');

const priceVal = document.getElementById('priceVal');
const mktVal = document.getElementById('mktVal');
const hireVal = document.getElementById('hireVal');
const convVal = document.getElementById('convVal');
const monthsVal = document.getElementById('monthsVal');
const modeEl = document.getElementById('agentMode');
const companyEl = document.getElementById('companyName');
const dynamicToggle = document.getElementById('dynamicToggle');
const growthEl = document.getElementById('baseGrowthPct');
const seasonEl = document.getElementById('seasonalityPct');
const noiseEl = document.getElementById('noisePct');
const growthVal = document.getElementById('growthVal');
const seasonVal = document.getElementById('seasonVal');
const noiseVal = document.getElementById('noiseVal');

const usageCount = document.getElementById('usageCount');
const billedAmount = document.getElementById('billedAmount');
const companyBadge = document.getElementById('companyBadge');

const simulateBtn = document.getElementById('simulateBtn');
const adviceBtn = document.getElementById('adviceBtn');
const exportBtn = document.getElementById('exportBtn');
const adviceList = document.getElementById('adviceList');

let chart;
let lastAdvice = [];
let lastResults = null;
let lastKpis = { rev: null, exp: null, prof: null };

function syncLabels() {
  priceVal.textContent = priceEl.value;
  mktVal.textContent = mktEl.value;
  hireVal.textContent = hireEl.value;
  convVal.textContent = convEl.value;
  monthsVal.textContent = monthsEl.value;
  if (growthVal) growthVal.textContent = growthEl.value;
  if (seasonVal) seasonVal.textContent = seasonEl.value;
  if (noiseVal) noiseVal.textContent = noiseEl.value;
  if (companyBadge && companyEl) {
    const name = (companyEl.value || '').trim() || 'Your Company';
    companyBadge.textContent = name;
  }
}

// Keep labels/badge synced
[priceEl, mktEl, hireEl, convEl, monthsEl, growthEl, seasonEl, noiseEl, companyEl]
  .forEach(el => el?.addEventListener('input', syncLabels));

// range <-> number two-way binding
function bindPair(rangeEl, numberEl, min, max) {
  if (!rangeEl || !numberEl) return;
  const clamp = (v) => Math.min(max, Math.max(min, v));
  rangeEl.addEventListener('input', () => { numberEl.value = rangeEl.value; syncLabels(); });
  numberEl.addEventListener('input', () => {
    const v = clamp(Number(numberEl.value));
    numberEl.value = String(v);
    rangeEl.value = String(v);
    syncLabels();
  });
}
bindPair(priceEl, priceNum, -30, 50);
bindPair(mktEl, mktNum, 0, 100000);
bindPair(hireEl, hireNum, 0, 10);
bindPair(convEl, convNum, 0, 50);
bindPair(monthsEl, monthsNum, 3, 24);
syncLabels();

async function getUsage() {
  try {
    const res = await fetch(`${apiBase}/usage`);
    const u = await res.json();
    usageCount.textContent = u.scenarios;
    billedAmount.textContent = u.billed.toFixed(2);
  } catch (err) {
    console.error('Failed to fetch usage:', err);
  }
}

function getPayload() {
  return {
    priceChangePct: +priceEl.value,
    marketingExtra: +mktEl.value,
    hires: +hireEl.value,
    conversionLiftPct: +convEl.value,
    months: +monthsEl.value,
    mode: modeEl?.value || 'balanced',
    company: companyEl?.value?.trim() || '',
    dynamic: !!dynamicToggle?.checked,
    baseGrowthPct: +growthEl?.value || 0,
    seasonalityPct: +seasonEl?.value || 0,
    noisePct: +noiseEl?.value || 0,
  };
}

async function simulate() {
  const payload = getPayload();
  try {
    const res = await fetch(`${apiBase}/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      throw new Error(`HTTP error! Status: ${res.status}`);
    }
    const data = await res.json();
    renderResults(data);
    await getUsage();
  } catch (err) {
    console.error('Simulation failed:', err);
    // You might want to show an error message on the UI here
  }
}

function renderResults({ results }) {
  const { adjustedRevenue, adjustedExpenses, monthlyProfit, runwayMonths, forecast } = results;
  const runwayText = (runwayMonths === Infinity)
    ? 'Profitable (infinite runway)'
    : (Number.isFinite(runwayMonths) ? `${runwayMonths} months runway` : '—');
  
  // Update KPI cards
  const kRev = document.getElementById('kpiRevenue');
  const kExp = document.getElementById('kpiExpenses');
  const kProf = document.getElementById('kpiProfit');
  const kRun = document.getElementById('kpiRunway');

  if (kRev) kRev.textContent = `₹${Number(adjustedRevenue.toFixed(0)).toLocaleString()}`;
  if (kExp) kExp.textContent = `₹${Number(adjustedExpenses.toFixed(0)).toLocaleString()}`;
  if (kProf) kProf.textContent = `₹${Number(monthlyProfit.toFixed(0)).toLocaleString()}`;
  if (kRun) kRun.textContent = runwayText;
  
  // Store results for later (e.g., PDF export)
  lastResults = { adjustedRevenue, adjustedExpenses, monthlyProfit, runwayMonths };
  
  // KPI trend coloring
  if (kRev) {
    const prev = lastKpis.rev; lastKpis.rev = adjustedRevenue;
    kRev.classList.remove('up', 'down'); if (prev != null) kRev.classList.add(adjustedRevenue >= prev ? 'up' : 'down');
  }
  if (kExp) {
    const prev = lastKpis.exp; lastKpis.exp = adjustedExpenses;
    kExp.classList.remove('up', 'down'); if (prev != null) kExp.classList.add(adjustedExpenses <= prev ? 'up' : 'down');
  }
  if (kProf) {
    const prev = lastKpis.prof; lastKpis.prof = monthlyProfit;
    kProf.classList.remove('up', 'down'); if (prev != null) kProf.classList.add(monthlyProfit >= prev ? 'up' : 'down');
  }
  
  const labels = forecast.map(f => `M${f.month}`);
  const profits = forecast.map(f => f.profit);
  const revenues = forecast.map(f => f.revenue);
  const expenses = forecast.map(f => f.expenses);
  const cashSeries = forecast.map(f => f.cash);

  if (!chart) {
    const ctx = document.getElementById('profitChart').getContext('2d');
    chart = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [
          {
            label: 'Revenue',
            data: revenues,
            borderColor: '#10b981',
            backgroundColor: 'rgba(16,185,129,0.15)',
            tension: 0.25,
            yAxisID: 'y',
          },
          {
            label: 'Expenses',
            data: expenses,
            borderColor: '#ef4444',
            backgroundColor: 'rgba(239,68,68,0.12)',
            tension: 0.25,
            yAxisID: 'y',
          },
          {
            label: 'Profit',
            data: profits,
            borderColor: '#3b82f6',
            backgroundColor: 'rgba(59,130,246,0.18)',
            tension: 0.25,
            fill: true,
            yAxisID: 'y',
          },
          {
            label: 'Cash',
            data: cashSeries,
            borderColor: '#f59e0b',
            backgroundColor: 'rgba(245,158,11,0.1)',
            tension: 0.25,
            yAxisID: 'y1',
          },
          {
            label: 'Breakeven',
            data: labels.map(() => 0),
            borderColor: '#64748b',
            borderDash: [4, 4],
            pointRadius: 0,
            tension: 0,
            yAxisID: 'y',
            hidden: true
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: { labels: { color: '#cbd5e1' } },
          tooltip: {
            callbacks: {
              label: (ctx) => `${ctx.dataset.label}: ₹${Number(ctx.parsed.y).toLocaleString()}`
            }
          }
        },
        scales: {
          x: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(148,163,184,0.1)' } },
          y: {
            position: 'left',
            ticks: {
              color: '#94a3b8',
              callback: (v) => '₹' + Number(v).toLocaleString()
            },
            grid: { color: 'rgba(148,163,184,0.08)' }
          },
          y1: {
            position: 'right',
            ticks: {
              color: '#94a3b8',
              callback: (v) => '₹' + Number(v).toLocaleString()
            },
            grid: { drawOnChartArea: false }
          }
        }
      }
    });
    // Apply current toggles to the newly created chart
    applyToggles?.();
  } else {
    chart.data.labels = labels;
    chart.data.datasets[0].data = revenues;
    chart.data.datasets[1].data = expenses;
    chart.data.datasets[2].data = profits;
    chart.data.datasets[3].data = cashSeries;
    chart.data.datasets[4].data = labels.map(() => 0);
    chart.update();
    applyToggles?.();
  }
}

async function getAdvice() {
  const payload = getPayload();
  adviceBtn.disabled = true;
  adviceBtn.textContent = 'Getting advice...';
  adviceList.innerHTML = '<li><em>Loading...</em></li>';
  try {
    const res = await fetch(`${apiBase}/recommend`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`HTTP ${res.status}: ${text}`);
    }
    const data = await res.json();
    lastAdvice = data.advice || [];
    if (!lastAdvice.length) {
      adviceList.innerHTML = `<li>No recommendations available for the current inputs (mode: ${data.mode || payload.mode}).</li>`;
    } else {
      const title = `Mode: ${data.mode || payload.mode}`;
      adviceList.innerHTML = `<li><em>${title}</em></li>` + lastAdvice
        .map(a => `<li><strong>${a.action}</strong><br/><small>${a.rationale}</small></li>`)
        .join('');
    }
  } catch (err) {
    console.error('Advice error:', err);
    adviceList.innerHTML = `<li style="color:#fca5a5">Advice failed: ${err.message}</li>`;
  } finally {
    adviceBtn.disabled = false;
    adviceBtn.textContent = 'Get Advice';
  }
}

async function exportReport() {
  const payload = getPayload();
  try {
    const res = await fetch(`${apiBase}/report`, { method: 'POST', body: JSON.stringify(payload) });
    if (!res.ok) {
        throw new Error(`HTTP error! Status: ${res.status}`);
    }
    await getUsage();

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const companyName = companyEl?.value?.trim() || 'Company';
    doc.text(`${companyName} — CFO Helper Scenario Report`, 14, 20);
    let summaryText = 'No summary available';
    if (lastResults) {
      const { adjustedRevenue, adjustedExpenses, monthlyProfit, runwayMonths } = lastResults;
      const runwayText = runwayMonths === Infinity ? 'Profitable (infinite runway)' : `${runwayMonths} months runway`;
      summaryText = `Revenue: ₹${Number(adjustedRevenue.toFixed(2)).toLocaleString()}\n` +
        `Expenses: ₹${Number(adjustedExpenses.toFixed(2)).toLocaleString()}\n` +
        `Monthly Profit: ₹${Number(monthlyProfit.toFixed(2)).toLocaleString()}\n` +
        `Runway: ${runwayText}`;
    }

    // Always print summary
    doc.text(summaryText, 14, 35, { maxWidth: 180 });
    // Optionally print recommendations
    if (lastAdvice.length) {
      const modeName = (modeEl?.options[modeEl.selectedIndex]?.text || 'Balanced');
      doc.text(`Recommendations (${modeName}):`, 14, 60);
      const lines = lastAdvice.map((a, i) => `${i + 1}. ${a.action} — ${a.rationale}`);
      doc.text(lines.join('\n'), 14, 68, { maxWidth: 180 });
    }

    const safeName = (companyName || 'Company').replace(/[^a-z0-9]+/gi, '-').replace(/^-+|-+$/g, '');
    const filename = `${safeName || 'Company'}-cfo-helper-report.pdf`;
    doc.save(filename);
  } catch (err) {
    console.error('Report export failed:', err);
    // You might want to show an error message on the UI here
  }
}

// Event Listeners
simulateBtn.addEventListener('click', simulate);
adviceBtn.addEventListener('click', getAdvice);
exportBtn.addEventListener('click', exportReport);

// Dynamic input toggling
if (dynamicToggle) {
    dynamicToggle.addEventListener('change', () => {
        const dynamicInputs = document.getElementById('dynamicInputs');
        if (dynamicInputs) {
            dynamicInputs.style.display = dynamicToggle.checked ? 'block' : 'none';
        }
    });
}

// Initial setup
window.addEventListener('load', () => {
    syncLabels();
    getUsage();
    // Simulate initial scenario on load
    simulate();
});
